<?php

if (!defined('ABSPATH')) {
	exit;
}

return [
	'key' => '001_insert_test_row',
	'title' => 'Insert Malibu test row',
	'description' => 'Inserts one example row into the Malibu test table.',
	'callback' => static function () {
		global $wpdb;

		$table = $wpdb->prefix . 'malibu_test_items';
		if (!malibu_migrations_table_exists($table)) {
			return new WP_Error(
				'malibu_example_table_missing',
				'Example table is missing. Run migrations first.'
			);
		}

		$existing_id = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id
				FROM {$table}
				WHERE code = %s
				LIMIT 1",
				'example-row'
			)
		);

		if ($existing_id > 0) {
			return [
				'summary' => 'Example row already exists.',
				'messages' => [
					'Existing row id: ' . $existing_id . '.',
				],
			];
		}

		$inserted = $wpdb->insert(
			$table,
			[
				'code' => 'example-row',
				'label' => 'Example migration row',
				'created_at' => current_time('mysql'),
			],
			[
				'%s',
				'%s',
				'%s',
			]
		);

		if ($inserted === false) {
			return new WP_Error(
				'malibu_example_insert_failed',
				'Example row insert failed: ' . (string) $wpdb->last_error
			);
		}

		return [
			'summary' => 'Example row inserted.',
			'messages' => [
				'Row code: example-row.',
			],
		];
	},
];
