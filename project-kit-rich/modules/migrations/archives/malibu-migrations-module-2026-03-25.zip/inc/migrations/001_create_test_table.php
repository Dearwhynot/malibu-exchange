<?php

if (!defined('ABSPATH')) {
	exit;
}

return [
	'key' => '001_create_test_table',
	'title' => 'Create Malibu test table',
	'description' => 'Creates a small example table for migration smoke testing.',
	'callback' => static function () {
		global $wpdb;

		$table = $wpdb->prefix . 'malibu_test_items';
		$charset_collate = $wpdb->get_charset_collate();

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			code varchar(64) NOT NULL,
			label varchar(191) NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY code (code)
		) {$charset_collate};";

		dbDelta($sql);

		if (!malibu_migrations_table_exists($table)) {
			return new WP_Error(
				'malibu_example_table_missing',
				'Example table was not created.'
			);
		}

		return [
			'summary' => 'Example test table is ready.',
			'messages' => [
				'Table: ' . $table . '.',
			],
		];
	},
];
